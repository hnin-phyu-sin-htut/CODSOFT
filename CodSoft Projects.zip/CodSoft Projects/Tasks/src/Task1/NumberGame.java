package Task1;

import java.util.Random;
import java.util.Scanner;

public class NumberGame {
    public static void main(String[] args) {
        // Game Over!
        // You won!

        Random random = new Random();
        int randomNumber = random.nextInt(100) + 1;
        System.out.println("Random Number : " + randomNumber);
        Scanner scanner = new Scanner(System.in);

        System.out.println("\"Welcome to the Number Guessing Game!\"\n***************************************");
        System.out.println("NOTE: Generated random number is between 1 to 100.");
        System.out.println("NOTE: You have 3 limit attempts to guess a number.");
        System.out.println("---------------------------------------------");

        int guessNumber;
        int maxAttempts = 3;
        int noOfAttempts;

        for (noOfAttempts = 1; noOfAttempts <= maxAttempts; noOfAttempts++){
            System.out.print("Attempt " + noOfAttempts + ": " + "Please enter a guess number: ");
            guessNumber = scanner.nextInt();

            if (guessNumber == randomNumber){
                int score = 100 - (25 * (noOfAttempts - 1));
                System.out.println("************** You won! ****************");
                System.out.printf("The number of attempts you tried: %s attempt(s).\n", noOfAttempts);
                System.out.printf("Your score is %s.\n", score);
                System.out.println("Congratulations! Your guess number is correct.\nYou played the Number Guessing Game well.");
                break;
            } else if ((guessNumber > randomNumber) && (noOfAttempts != maxAttempts)){
                System.out.println("Your guess number is too high.");
                System.out.println("---------------------------------------------");
            } else if ((guessNumber < randomNumber) && (noOfAttempts != maxAttempts)) {
                System.out.println("Your guess number is too low.");
                System.out.println("---------------------------------------------");
            }

            if (noOfAttempts == maxAttempts){
                System.out.println("************** Game Over! ****************");
                System.out.println("No more remaining attempts.");
                System.out.printf("The correct random number was %s.", "\"" + randomNumber + "\"");
            }

        }

    }

}





















