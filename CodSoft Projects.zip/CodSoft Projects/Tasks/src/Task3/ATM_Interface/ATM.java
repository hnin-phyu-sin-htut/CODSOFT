package Task3.ATM_Interface;

import java.util.Scanner;

public class ATM extends BankAccount {

    public ATM(String accountNumber, String accountHolderName, double accountBalance) {
        super(accountNumber, accountHolderName, accountBalance);
    }
}
