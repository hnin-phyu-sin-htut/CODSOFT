package Task3.ATM_Interface;

public class BankAccount {
    public String accountNumber;
    public String accountHolderName;
    public double accountBalance;

    public BankAccount(String accountNumber, String accountHolderName, double accountBalance) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.accountBalance = accountBalance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public double withdraw(double money){
        if (accountBalance >= money){
            accountBalance -= money;
        }
        else {
            return accountBalance;
        }
        return accountBalance;
    }

    public void deposit(double money){
        if (money > 0){
            accountBalance += money;
        } else {
            System.out.println("Invalid Amount!");
        }
    }
}
