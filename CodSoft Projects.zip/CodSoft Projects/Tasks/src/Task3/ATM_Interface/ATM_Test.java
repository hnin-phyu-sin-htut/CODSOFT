package Task3.ATM_Interface;

import java.util.Scanner;

public class ATM_Test {
    /*
        ** Options **
        1. Withdrawing
        2. Depositing
        3. Checking Balance
    */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ATM atm = new ATM("ACC0001", "Hnin Phyu", 50000);

        System.out.println("Welcome to ATM machine!");
        System.out.println("***********************");

        while (true){
            System.out.println("\nNOTE: Enter Number 1 to check Wallet Balance.");
            System.out.println("NOTE: Enter Number 2 to Deposit Money.");
            System.out.println("NOTE: Enter Number 3 to Withdraw Money.");
            System.out.println("NOTE: Enter Number 4 to Exit.");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();

            if (option == 4) {
                System.out.println("Exiting... Thank you for using our ATM!");
                break;
            }

            String options = switch (option){
                case 1 -> {
                    System.out.println("Your account balance: " + atm.getAccountBalance());
                    yield "Here is your account balance.";
                }
                case 2 -> {
                    System.out.println("Your account balance: " + atm.getAccountBalance());
                    System.out.print("Enter an amount to deposit money: ");
                    double depositMoney = scanner.nextDouble();
                    atm.deposit(depositMoney);
                    System.out.println("Your account balance: " + atm.getAccountBalance());
                    yield "Deposit Successful!";
                }
                case 3 -> {
                    System.out.println("Your account balance: " + atm.getAccountBalance());
                    System.out.print("Enter an amount to withdraw money: ");
                    double withdrawMoney = scanner.nextDouble();

                    double initialBalance = atm.getAccountBalance();
                    atm.withdraw(withdrawMoney);

                    if (atm.getAccountBalance() == initialBalance){
                        yield "Withdraw Failed due to insufficient balance!";
                    } else {
                        System.out.println("Your account balance: " + atm.getAccountBalance());
                        yield "Withdraw Successful!";
                    }
                }
                default -> "Invalid Input!";
            };
            System.out.println(options);
        }

    }
}
