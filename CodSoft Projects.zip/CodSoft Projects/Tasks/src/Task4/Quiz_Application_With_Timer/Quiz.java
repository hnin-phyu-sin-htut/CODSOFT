package Task4.Quiz_Application_With_Timer;

import java.util.*;
import java.util.concurrent.*;

public class Quiz {
    private static Scanner scanner = new Scanner(System.in);
    private static final int TIME_LIMIT = 10; // 10 seconds for each question
    private static int score = 0;

    static class Question{
        String question;
        String[] options;
        int correctAnswer;

        Question(String question, String[] options, int correctAnswer) {
            this.question = question;
            this.options = options;
            this.correctAnswer = correctAnswer;
        }
    }

    public static void main(String[] args) {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("What is the default value of an instance variable of type int in Java?", new String[]{"1. 0", "2. Null", "3. 1"}, 1));
        questions.add(new Question("Which keyword is used to define a constant variable in Java?", new String[]{"1. static", "2. final", "3. const"}, 2));
        questions.add(new Question("What will System.out.println(10 / 3); output?", new String[]{"1. 3.33", "2. 3", "3. 3.0"}, 2));

        runQuiz(questions);
    }

    private static void runQuiz(List<Question> questions) {
        int questionNumber = 1;
        for (Question q : questions) {
            System.out.println("Question " + questionNumber + ": " + q.question);
            for (String option : q.options) {
                System.out.println(option);
            }

            int userAnswer = getUserAnswer();
            if (userAnswer == q.correctAnswer) {
                System.out.println("Your answer is correct!\n");
                score++;
            } else {
                System.out.println("Wrong! The correct answer was: " + q.correctAnswer + "\n");
            }
            questionNumber++;
        }

        System.out.println("Quiz Over! Your final score is " + score + " out of " + questions.size() + ".");
    }

    private static int getUserAnswer() {
        final ExecutorService executorService = Executors.newSingleThreadExecutor();
        Future<Integer> future = executorService.submit(() -> {
            System.out.print("Enter your choice (1-4) within " + TIME_LIMIT + " seconds: ");
            return scanner.nextInt();
        });

        try {
            return future.get(TIME_LIMIT, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            System.out.println("\nTime's up! Moving to the next question.\n");
            return -1;
        } catch (Exception e) {
            System.out.println("\nInvalid input! Moving to the next question.\n");
            return -1;
        } finally {
            executorService.shutdown();
        }
    }
}
