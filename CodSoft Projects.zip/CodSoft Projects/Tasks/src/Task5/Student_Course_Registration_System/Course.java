package Task5.Student_Course_Registration_System;

import java.util.ArrayList;
import java.util.List;

public class Course {
    String course_code, title, description, schedule;
    int capacity;
    List<Student> enrolledStudents;

    public Course(String course_code, String title, String description, String schedule, int capacity) {
        this.course_code = course_code;
        this.title = title;
        this.description = description;
        this.schedule = schedule;
        this.capacity = capacity;
        this.enrolledStudents = new ArrayList<>();
    }

    public boolean registerStudent(Student student) {
        if (enrolledStudents.size() < capacity) {
            enrolledStudents.add(student);
            student.registerCourse(this);
            return true;
        }
        return false;
    }

    public boolean dropStudent(Student student) {
        if (enrolledStudents.contains(student)) {
            enrolledStudents.remove(student);
            student.dropCourse(this);
            return true;
        }
        return false;
    }

    public int getAvailableSlots() {
        return capacity - enrolledStudents.size();
    }

    public void displayCourse() {
        System.out.println("Course Code: " + course_code + ", Title: " + title + ", Slots: " + getAvailableSlots() + "/" + capacity);
        System.out.println("Description: " + description + " | Schedule: " + schedule);
    }
}
