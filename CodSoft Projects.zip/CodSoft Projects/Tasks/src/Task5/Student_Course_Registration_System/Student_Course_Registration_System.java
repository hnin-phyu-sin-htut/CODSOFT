package Task5.Student_Course_Registration_System;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Student_Course_Registration_System {
    static List<Course> courses = new ArrayList<>();
    static List<Student> students = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Course c1 = new Course("CS2023", "Introduction to Computer Science", "Basic Programming Concepts", "Mon - Fri, 9AM - 4PM", 7);
        Course c2 = new Course("ENG2025", "IELTS", "Proficient English", "Fri - Sun, 6PM - 8PM", 5);
        courses.add(c1);
        courses.add(c2);

        Student s1 = new Student("S0001", "John Smith");
        Student s2 = new Student("S0002", "Jennie Kim");
        Student s3 = new Student("S0003", "Rose Mary");
        students.add(s1);
        students.add(s2);
        students.add(s3);

        while (true) {
            System.out.println("1. List Courses\n2. Register Course\n3. Drop Course\n4. View Registered Courses\n5. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    for (Course course : courses) {
                        course.displayCourse();
                    }
                    break;
                case 2:
                    System.out.print("Enter Student ID: ");
                    String studentId = scanner.nextLine();
                    System.out.print("Enter Course Code: ");
                    String courseCode = scanner.nextLine();
                    Student student = findStudent(studentId);
                    Course course = findCourse(courseCode);
                    if (student != null && course != null) {
                        if (course.registerStudent(student)) {
                            System.out.println("Registered successfully!");
                        } else {
                            System.out.println("Course full!");
                        }
                    }
                    break;
                case 3:
                    System.out.print("Enter Student ID: ");
                    studentId = scanner.nextLine();
                    System.out.print("Enter Course Code: ");
                    courseCode = scanner.nextLine();
                    student = findStudent(studentId);
                    course = findCourse(courseCode);
                    if (student != null && course != null) {
                        if (course.dropStudent(student)) {
                            System.out.println("Dropped successfully!");
                        } else {
                            System.out.println("Not registered in course!");
                        }
                    }
                    break;
                case 4:
                    System.out.print("Enter Student ID: ");
                    studentId = scanner.nextLine();
                    student = findStudent(studentId);
                    if (student != null) student.displayRegisteredCourses();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
    private static Student findStudent(String id) {
        for (Student s : students) {
            if (s.student_id.equals(id)) return s;
        }
        System.out.println("Student not found!");
        return null;
    }

    private static Course findCourse(String code) {
        for (Course c : courses) {
            if (c.course_code.equals(code)) return c;
        }
        System.out.println("Course not found!");
        return null;
    }
}

