package Task5.Student_Course_Registration_System;

import java.util.ArrayList;
import java.util.List;

public class Student {
    String student_id;
    String student_name;
    List<Course> registeredCourses;

    public Student(String student_id, String student_name) {
        this.student_id = student_id;
        this.student_name = student_name;
        this.registeredCourses = new ArrayList<>();
    }

    public void registerCourse(Course course) {
        registeredCourses.add(course);
    }

    public void dropCourse(Course course) {
        registeredCourses.remove(course);
    }

    public void displayRegisteredCourses() {
        for (Course course : registeredCourses) {
            System.out.println(student_name + "'s Registered Courses:");
            System.out.println("- " + course.title + " (" + course.course_code + ")");
        }
        if (registeredCourses.isEmpty()) {
            System.out.println("Not Registered in course!");
        }
    }


}
