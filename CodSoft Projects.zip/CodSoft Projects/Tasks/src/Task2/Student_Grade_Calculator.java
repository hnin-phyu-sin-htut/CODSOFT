package Task2;

import java.util.Scanner;

public class Student_Grade_Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("STUDENT GRADE CALCULATOR\n-------------------------");
        System.out.print("Subject 1: ");
        int subject1 = scanner.nextInt();

        System.out.print("Subject 2: ");
        int subject2 = scanner.nextInt();

        System.out.print("Subject 3: ");
        int subject3 = scanner.nextInt();

        System.out.print("Subject 4: ");
        int subject4 = scanner.nextInt();

        int sum = sum(subject1, subject2, subject3, subject4);
        System.out.printf("Total Marks: %s\n", sum);

        int average = average(subject1, subject2, subject3, subject4);
        System.out.println("Average Marks: " + average + "%");

        if (average >= 80){
            System.out.println("Your score: A");
        } else if (average < 80 && average >= 50) {
            System.out.println("Your score: B");
        }else {
            System.out.println("Your score: C");
        }

    }

    public static int sum(int subject1, int subject2, int subject3, int subject4){
        int sum = subject1 + subject2 + subject3 + subject4;
        return sum;
    }

    public static int average(int subject1, int subject2, int subject3, int subject4){
        int sum = sum(subject1, subject2, subject3, subject4);
        int totalSubject = 4;
        return sum / totalSubject;
    }
}
